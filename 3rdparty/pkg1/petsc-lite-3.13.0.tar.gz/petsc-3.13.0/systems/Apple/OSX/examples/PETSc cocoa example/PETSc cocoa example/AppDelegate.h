//
//  AppDelegate.h
//  PETSc cocoa example
//
//  Created by Barry Smith on 8/2/12.
//  Copyright (c) 2012 Barry Smith. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@end
