#include "test_hmat_auto.hpp"

int main(int argc, char *argv[]) {

    return test_hmat_auto<GeometricClustering, partialACA>(argc, argv, 0.5);
}
