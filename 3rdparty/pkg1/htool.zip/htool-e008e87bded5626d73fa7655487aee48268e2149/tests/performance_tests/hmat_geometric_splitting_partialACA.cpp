#include "hmat.hpp"

int main(int argc, char *argv[]) {

    hmat<GeometricClustering, partialACA>(argc, argv);

    return 0;
}
