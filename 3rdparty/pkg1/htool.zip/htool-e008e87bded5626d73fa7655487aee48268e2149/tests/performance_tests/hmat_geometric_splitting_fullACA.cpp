#include "hmat.hpp"

int main(int argc, char *argv[]) {

    hmat<GeometricClustering, fullACA>(argc, argv);

    return 0;
}
